# Duong Linh — Fabric 1.21.11

This is a source project for a Minecraft Java 1.21.11 Fabric mod based on the identifier in the supplied Bedrock add-on (`duonglinh:duonglinh`). Bedrock `.mcaddon` files cannot be directly converted into Java `.jar` mods, so this recreates the item as a Java item.

## Effects
- Put the Duong Linh item in the off-hand (left hand): Speed II is refreshed while held.
- Regenerates 1 health point every second while held, provided the player is not at full health.
- The Java item currently uses the vanilla amethyst-shard appearance because the supplied `.mcaddon` contains no resource-pack texture for the item.

## Build
Requires JDK 21 and an internet connection for Gradle to download Minecraft/Fabric dependencies.

From this folder run:

```bash
gradle build
```

The mod jar will be created under `build/libs/`. Install Fabric Loader and Fabric API for Minecraft 1.21.11, then place the built jar in the `mods` folder.

Note: this project recreates the item and its effects; it does not import Bedrock behavior-pack files into Java.
