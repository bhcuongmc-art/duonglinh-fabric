package com.duonglinh.mod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.server.network.ServerPlayerEntity;

public class DuongLinhMod implements ModInitializer {
    public static final String MOD_ID = "duonglinh";
    public static final Item DUONGLINH = Registry.register(
            Registries.ITEM,
            Identifier.of(MOD_ID, "duonglinh"),
            new Item(new Item.Settings().maxCount(1))
    );

    @Override
    public void onInitialize() {
        ServerTickEvents.END_PLAYER_TICK.register(player -> {
            if (!(player instanceof ServerPlayerEntity serverPlayer)) return;
            ItemStack offHand = serverPlayer.getOffHandStack();
            if (!offHand.isOf(DUONGLINH)) return;

            // Regenerate 1 health point every second while held in the off-hand.
            if (serverPlayer.age % 20 == 0 && serverPlayer.getHealth() < serverPlayer.getMaxHealth()) {
                serverPlayer.heal(1.0F);
            }
            // Speed II, refreshed while the item remains in the off-hand.
            serverPlayer.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 40, 1, true, false, false));
        });
    }
}
